import javax.swing.*;
import java.sql.*;

public class PatientForm extends JFrame {
    JTextField n, a;

    public PatientForm() {
        setSize(300, 250);
        setLayout(null);
        n = new JTextField();
        n.setBounds(100, 30, 120, 25);
        add(n);
        a = new JTextField();
        a.setBounds(100, 70, 120, 25);
        add(a);
        JButton b = new JButton("Add");
        b.setBounds(100, 120, 100, 30);
        add(b);
        b.addActionListener(e -> add());
        setVisible(true);
    }

    void add() {
        try {
            Connection c = DBConnection.getConnection();
            PreparedStatement ps = c.prepareStatement("insert into patients(name,age) values(?,?)");
            ps.setString(1, n.getText());
            ps.setInt(2, Integer.parseInt(a.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Added");
        } catch (Exception ex) {
        }
    }
}