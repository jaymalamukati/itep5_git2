import javax.swing.*;
import java.sql.*;

public class LoginForm extends JFrame {
    JTextField u;
    JPasswordField p;

    public LoginForm() {
        setSize(300, 200);
        setLayout(null);
        u = new JTextField();
        u.setBounds(100, 30, 120, 25);
        add(u);
        p = new JPasswordField();
        p.setBounds(100, 70, 120, 25);
        add(p);
        JButton b = new JButton("Login");
        b.setBounds(100, 110, 100, 30);
        add(b);
        b.addActionListener(e -> login());
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    void login() {
        try {
            Connection c = DBConnection.getConnection();
            PreparedStatement ps = c.prepareStatement("select * from users where username=? and password=?");
            ps.setString(1, u.getText());
            ps.setString(2, new String(p.getPassword()));
            ResultSet r = ps.executeQuery();
            if (r.next()) {
                new Dashboard();
                dispose();
            } else
                JOptionPane.showMessageDialog(this, "Invalid");
        } catch (Exception ex) {
        }
    }

    public static void main(String[] a) {
        new LoginForm();
    }
}